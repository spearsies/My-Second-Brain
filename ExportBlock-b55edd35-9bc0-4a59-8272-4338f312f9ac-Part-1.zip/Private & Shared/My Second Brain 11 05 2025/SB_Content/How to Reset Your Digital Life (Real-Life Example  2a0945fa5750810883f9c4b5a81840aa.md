# How to Reset Your Digital Life (Real-Life Example and Coaching)

Type: YouTube video
Link: https://www.youtube.com/watch?v=1cZaqHJ3fXw
Status: Not started
Date added: November 3, 2025 12:01 PM