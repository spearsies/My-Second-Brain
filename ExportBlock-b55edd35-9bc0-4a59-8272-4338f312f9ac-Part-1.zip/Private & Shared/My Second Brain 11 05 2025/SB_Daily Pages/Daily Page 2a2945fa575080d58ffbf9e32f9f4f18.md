# Daily Page

Date: November 5, 2025
Slept 7+hours: No
Tasks: Contact Ty from USA Cares to see if you can connect and find out about any resources. (../SB_Tasks/Contact%20Ty%20from%20USA%20Cares%20to%20see%20if%20you%20can%20connec%202a2945fa575080339ef4dbb053bdee7a.md)

## Startup Checklist

- [ ]  Change the name of the page to today’s date
- [ ]  Write a morning brain dump
- [ ]  Check today’s calendar

---

---

## Shutdown Checklist

- [ ]  Capture a win
- [ ]  Check the calendar for the rest of the week
- [ ]  Plan tasks for tomorrow