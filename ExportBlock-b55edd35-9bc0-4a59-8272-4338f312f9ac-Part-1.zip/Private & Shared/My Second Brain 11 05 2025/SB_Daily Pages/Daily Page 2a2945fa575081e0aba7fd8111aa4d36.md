# Daily Page

Date: November 5, 2025
Slept 7+hours: No

## Startup Checklist

- [ ]  Change the name of the page to today’s date
- [ ]  Write a morning brain dump
- [ ]  Check today’s calendar

---

---

## Shutdown Checklist

- [ ]  Capture a win
- [ ]  Check the calendar for the rest of the week
- [ ]  Plan tasks for tomorrow