# Contact Ty from USA Cares to see if you can connect and find out about any resources.

Do on: November 5, 2025
Status: Not started
Daily Page: Daily Page (../SB_Daily%20Pages/Daily%20Page%202a2945fa575080d58ffbf9e32f9f4f18.md)
Notes: Untitled (../SB_Notes/Untitled%202a2945fa575080648cb4fd4337463e0a.md)