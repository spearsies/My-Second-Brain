# Book diving trip

PARA: Plan Trip to Pittsburgh (../SB_PARA/Plan%20Trip%20to%20Pittsburgh%202a0945fa5750811c929ff63e28badd89.md)
Do on: March 19, 2025
Status: Not started