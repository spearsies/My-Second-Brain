# Book flight to Pittsburgh

PARA: Plan Trip to Pittsburgh (../SB_PARA/Plan%20Trip%20to%20Pittsburgh%202a0945fa5750811c929ff63e28badd89.md)
Deadline: November 11, 2025
Tags: Mom
Waiting on: Move  in Approval and Date
Status: Waiting on