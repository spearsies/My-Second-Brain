# Purchase new coffee grinder

PARA: Coffee (../SB_PARA/Coffee%202a0945fa575081288796f5a814140934.md)
Waiting on: Recommendation from Jarna
Status: Waiting on