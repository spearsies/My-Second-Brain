# Water the plants

PARA: Home (../SB_PARA/Home%202a0945fa575081888866fc230a1c8760.md)
Do on: February 27, 2025
Status: Not started