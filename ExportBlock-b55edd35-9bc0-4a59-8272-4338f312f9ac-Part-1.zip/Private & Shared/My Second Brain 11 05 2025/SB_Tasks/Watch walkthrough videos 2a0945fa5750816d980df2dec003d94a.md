# Watch walkthrough videos

PARA: Set up Second Brain Notion template (../SB_PARA/Set%20up%20Second%20Brain%20Notion%20template%202a0945fa575081ea97add964ba1b2006.md)
Do on: March 12, 2025
Status: Not started