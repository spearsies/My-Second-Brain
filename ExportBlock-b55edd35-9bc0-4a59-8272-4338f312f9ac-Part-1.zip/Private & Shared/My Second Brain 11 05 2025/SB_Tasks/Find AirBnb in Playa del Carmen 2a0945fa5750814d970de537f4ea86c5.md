# Find AirBnb in Playa del Carmen

PARA: Plan Trip to Pittsburgh (../SB_PARA/Plan%20Trip%20to%20Pittsburgh%202a0945fa5750811c929ff63e28badd89.md)
Deadline: March 12, 2025
Waiting on: Hearing back from host
Status: Waiting on