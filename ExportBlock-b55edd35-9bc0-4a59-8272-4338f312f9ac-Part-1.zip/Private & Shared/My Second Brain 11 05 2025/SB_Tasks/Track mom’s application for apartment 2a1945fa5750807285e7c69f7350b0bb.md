# Track mom’s application for apartment

PARA: The PARA Method (../SB_PARA/The%20PARA%20Method%202a0945fa57508140aa6ee48e71da0b1d.md)
Tags: Mom
Waiting on: Ironhorse to send an updated price list
Status: Waiting on