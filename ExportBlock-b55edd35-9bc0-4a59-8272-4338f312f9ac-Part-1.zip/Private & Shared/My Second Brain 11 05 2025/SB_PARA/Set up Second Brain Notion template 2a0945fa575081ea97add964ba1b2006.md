# Set up Second Brain Notion template

Category: Project
Status: Active
Deadline: March 31, 2025