# The PARA Method

Category: Resource
Status: Active

[](https://lh7-rt.googleusercontent.com/docsz/AD_4nXexMiQhOlAL8L9e42M3xkKBIIeWUTdO2n-b4xQRw4rVE6NMkhKK1RbkJzyvUW5IV3SxF9dNpTIFe37cB1y_pc0meewNIsjgAEPkjd5LisEL8iE4KlJSxgW4I3cz-w0KRs-HSGVrvU3Y3o-9xZDoBuvuFNja?key=m8Od09OIOoWfVsJnQroYjA)

## How to Decide Where to Save a Piece of Information

When’s the next time you’ll need that piece of information? Follow this flowchart to find where best to store it.

[](https://lh7-rt.googleusercontent.com/docsz/AD_4nXdKtfHr2zlOGY992BvdMD4_f2IiAHTGFPiST49jKjPty16hCDHePox9orDSV8sPQGvmBnK3I2_5xkRGDZLgFC8jvAxLOmQTKq8K4vUOsIYX0S4OveUIcQkMJTuAoSJOlQAq7BvO7q27xv4Sqrm7OXGhtHA?key=m8Od09OIOoWfVsJnQroYjA)

## 5 Simple Rules for PARA Success

1. **Never create an empty folder before you have something to put in it.** Create a new folder, tag, directory, or container only if and when you truly need it.
2. **There’s no one correct place for any piece of information.** Any given file or document can go any number of places. Don’t overthink this decision. Use your intuition, rather than trying to categorize everything perfectly.
3. **Move quickly, touch lightly.** PARA is a dynamic system. Once you’ve added a note or document, it doesn’t have to stay in that location forever. Move it to where you need it most.
4. **Search is your friend.** When you’re looking for a piece of information within PARA, use the search function first. You’ll often find it much quicker than going into individual folders.
5. **When in doubt, start over.** If at any time you start to feel overwhelmed by the information swirling around you, move everything into an archive with today’s date, and start fresh.

## PARA Examples for Each Category

https://www.buildingasecondbrain.com/para/examples